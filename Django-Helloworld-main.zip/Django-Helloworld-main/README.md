# Django-Helloworld

#Download Python ➝ https://www.python.org/

#Download Django ➝ https://www.djangoproject.com/

#Download pip ➝ https://pip.pypa.io/en/stable/

#After cloning the project go to root folder

#Exceute command "python manage.py runserver"

#After that visit "http://127.0.0.1:8000/" to see the application
